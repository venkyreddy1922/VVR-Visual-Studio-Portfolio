# VVR Visual Studio (React + Vite)

    npm install
    npm run dev      # local preview
    npm run build    # production build in dist/

Edit your content in the `EDIT HERE` block at the top of `src/App.jsx`
(CONTACT, PROJECTS, STACK, SERVICES, ROLES). Put project images and videos in `public/`
and reference them like `/posters/p1.jpg`. Photos live in `public/hero1.jpg` and `public/hero2.jpg`.

## Contact form notifications (EmailJS)

Submissions are emailed to vangavenkateshwarreddy19@gmail.com through EmailJS.
Until you add your keys the form shows "nothing was sent" and never reports success.

1. Create a free account at https://www.emailjs.com and add an **Email Service** (for example Gmail).
2. Create an **Email Template**. Set **To Email** to `{{to_email}}` (or type the address directly),
   **Reply To** to `{{reply_to}}`, and use these variables in the subject and body:
   `{{from_name}}`, `{{from_email}}`, `{{phone}}`, `{{work}}`, `{{sent_at}}`.
3. Copy `.env.example` to `.env` and fill in the Service ID, Template ID and Public Key
   (Account > General > Public Key).
4. Restart `npm run dev`. On your hosting provider, add the same three variables
   before building, because Vite reads them at build time.

The public key is meant to be visible in the browser. Check your EmailJS plan limits and,
if you get spam, turn on EmailJS domain allow-listing or reCAPTCHA in its dashboard.
